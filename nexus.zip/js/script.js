document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();

    // Eye Password Toggles
    document.querySelectorAll('.eye-toggle').forEach(eye => {
        eye.addEventListener('click', function() {
            const input = this.previousElementSibling;
            if (input.type === 'password') {
                input.type = 'text';
                this.setAttribute('data-lucide', 'eye-off');
            } else {
                input.type = 'password';
                this.setAttribute('data-lucide', 'eye');
            }
            lucide.createIcons();
        });
    });

    // Form Submissions
    const handleAuth = async (formId, endpoint) => {
        const form = document.getElementById(formId);
        if (!form) return;

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const alertBox = form.querySelector('.alert');

            try {
                const response = await fetch(endpoint, {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();

                alertBox.textContent = data.message;
                alertBox.className = 'alert ' + (data.status === 'success' ? 'alert-success' : 'alert-error');
                alertBox.style.display = 'block';

                if (data.status === 'success') {
                    // Redirect to dashboard (PHP first, HTML fallback)
                    setTimeout(() => {
                        window.location.href = 'dashboard.html'; 
                    }, 1500);
                }
            } catch (error) {
                // Simulation Fallback
                console.warn("Backend not detected. Running Simulation.");
                if (formId === 'form-admin-login' && formData.get('security_phrase') === 'Subham Sorry dorry LOVE') {
                    alertBox.textContent = "Simulation: Override Accepted. Initializing Admin environment...";
                    alertBox.className = 'alert alert-success';
                    alertBox.style.display = 'block';
                    setTimeout(() => window.location.href = 'dashboard.html', 1500);
                } else if (formId === 'form-register') {
                    alertBox.textContent = "Simulation: Account created in local memory.";
                    alertBox.className = 'alert alert-success';
                    alertBox.style.display = 'block';
                }
            }
        });
    };

    handleAuth('form-user-login', 'api/auth/login_user.php');
    handleAuth('form-admin-login', 'api/auth/login_admin.php');
    handleAuth('form-register', 'api/auth/register.php');

    // Biometric Trigger
    window.triggerRetinaScan = function() {
        const video = document.getElementById('retina-cam');
        const overlay = document.querySelector('.scan-overlay');
        const alertBox = document.querySelector('#form-admin-login .alert');

        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => {
                video.srcObject = stream;
                video.style.display = 'block';
                overlay.style.display = 'block';
                
                setTimeout(() => {
                    alertBox.textContent = "Retina Pattern Recognized. Biometric Handshake Complete.";
                    alertBox.className = 'alert alert-success';
                    alertBox.style.display = 'block';
                    
                    // Stop stream
                    stream.getTracks().forEach(track => track.stop());
                    video.style.display = 'none';
                    overlay.style.display = 'none';

                    // Auto-fill override and submit for simulation
                    document.getElementById('admin-id').value = "SUPER_ADMIN_CORE";
                    document.getElementById('security-phrase').value = "Subham Sorry dorry LOVE";
                    document.getElementById('form-admin-login').dispatchEvent(new Event('submit'));
                }, 3000);
            })
            .catch(err => {
                alert("Camera access denied. Please use Security Phrase Override.");
            });
    }
});
