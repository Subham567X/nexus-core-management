<?php
// api/system_core.php - The Universal God Controller for the Nexus Core System
header('Content-Type: application/json');
require_once 'config/database.php';

use App\Config\Database;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Access Protocol.']);
    exit;
}

session_start();
$action = $_POST['action'] ?? '';

// Require authentication for all system core actions
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized. Please authenticate.']);
    exit;
}

$dbClass = new Database();
$db = $dbClass->getConnection();
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

switch ($action) {
    case 'submit_work':
        // Handle Work Update Panel Submissions
        $task_title = filter_input(INPUT_POST, 'task_title', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
        $progress = filter_input(INPUT_POST, 'progress', FILTER_VALIDATE_INT);
        
        if (isset($_FILES['work_file']) && $_FILES['work_file']['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES['work_file']['tmp_name'];
            $fileName = $_FILES['work_file']['name'];
            $fileExtension = strtoupper(pathinfo($fileName, PATHINFO_EXTENSION));

            // Security: In a real system, we query the team's allowed_extensions from the DB.
            // For simulation, we enforce a strict check against common formats:
            $allowed = ['BLEND', 'MA', 'FBX', 'OBJ', 'PNG', 'MP4', 'WAV', 'PDF', 'PSD'];
            
            if (!in_array($fileExtension, $allowed)) {
                echo json_encode(['status' => 'error', 'message' => 'SECURITY BLOCK: File extension .' . $fileExtension . ' is not authorized for your department.']);
                exit;
            }

            // Simulate file upload success
            echo json_encode(['status' => 'success', 'message' => 'Work file uploaded successfully. Progress updated to ' . $progress . '%. Pending Moderator review.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No valid work file detected.']);
        }
        break;

    case 'approve_member':
        // Member Control Logic
        if (!in_array($user_role, ['super_admin', 'sub_admin'])) {
            echo json_encode(['status' => 'error', 'message' => 'Clearance Denied.']);
            exit;
        }
        $target_id = filter_input(INPUT_POST, 'target_user_id', FILTER_VALIDATE_INT);
        
        $stmt = $db->prepare("UPDATE users SET status = 'active' WHERE id = :id AND status = 'pending'");
        $stmt->execute([':id' => $target_id]);
        
        echo json_encode(['status' => 'success', 'message' => 'Personnel access granted.']);
        break;

    case 'review_work':
        // Task Status System Logic
        if (!in_array($user_role, ['super_admin', 'sub_admin', 'team_moderator'])) {
            echo json_encode(['status' => 'error', 'message' => 'Clearance Denied.']);
            exit;
        }
        $submission_id = filter_input(INPUT_POST, 'submission_id', FILTER_VALIDATE_INT);
        $new_status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING); // e.g. 'approved', 'rejected', 'needs_fix'
        
        $stmt = $db->prepare("UPDATE work_submissions SET status = :status WHERE id = :id");
        $stmt->execute([':status' => $new_status, ':id' => $submission_id]);
        
        echo json_encode(['status' => 'success', 'message' => 'Work submission status updated to ' . strtoupper($new_status) . '.']);
        break;

    case 'create_admin_account':
        // Super Admin Access Required
        if ($user_role !== 'super_admin') {
            echo json_encode(['status' => 'error', 'message' => 'CRITICAL SECURITY: Only Super Admin can create Management Accounts.']);
            exit;
        }

        $full_name = filter_input(INPUT_POST, 'full_name', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $new_role = filter_input(INPUT_POST, 'new_role', FILTER_SANITIZE_STRING); // 'sub_admin' or 'team_moderator'

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid email format.']);
            exit;
        }

        // Generate Secure Credentials
        $login_id = 'NEXUS_' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6));
        $temp_password = 'NEXUS-' . bin2hex(random_bytes(4)) . '!';
        $hashed_password = password_hash($temp_password, PASSWORD_BCRYPT, ['cost' => 12]);
        $role_title = ($new_role === 'sub_admin') ? 'Sub Admin' : 'Team Moderator';

        try {
            // Save to Database
            $stmt = $db->prepare("INSERT INTO users (username, full_name, email, password_hash, role, status) VALUES (:username, :full_name, :email, :password_hash, :role, 'active')");
            $stmt->execute([
                ':username' => $login_id,
                ':full_name' => $full_name,
                ':email' => $email,
                ':password_hash' => $hashed_password,
                ':role' => $new_role
            ]);

            // --- PHPMailer Automated Email Generation ---
            // In a live environment, composer autoloader would be required: require 'vendor/autoload.php';
            // using PHPMailer\PHPMailer\PHPMailer;
            
            $htmlEmail = "
            <html>
            <body style='background-color: #0d0f12; color: #e2e8f0; font-family: Arial, sans-serif; padding: 30px; line-height: 1.6;'>
                <div style='max-width: 600px; margin: 0 auto; border: 1px solid #1f2937; border-radius: 8px; overflow: hidden; box-shadow: 0 0 20px rgba(0, 240, 255, 0.1);'>
                    <div style='background-color: #111827; padding: 20px; text-align: center; border-bottom: 2px solid #00f0ff;'>
                        <h1 style='color: #00f0ff; margin: 0; font-size: 24px; text-transform: uppercase; letter-spacing: 2px;'>NEXUS CORE</h1>
                        <p style='color: #9ca3af; margin: 5px 0 0 0; font-size: 12px;'>Management Account Provisioning</p>
                    </div>
                    <div style='padding: 30px; background-color: #1a1e23;'>
                        <p>Hello <strong>{$full_name}</strong>,</p>
                        <p>Welcome to NEXUS CORE. Your management account has been successfully created by the Super Admin team.</p>
                        
                        <h3 style='color: #00f0ff; border-bottom: 1px solid #374151; padding-bottom: 5px; margin-top: 25px;'>ACCOUNT DETAILS</h3>
                        <table style='width: 100%; color: #e2e8f0; border-collapse: collapse;'>
                            <tr><td style='padding: 8px 0; color: #9ca3af; width: 140px;'>Assigned Role:</td><td style='font-weight: bold; color: #f59e0b;'>{$role_title}</td></tr>
                            <tr><td style='padding: 8px 0; color: #9ca3af;'>Login ID / Email:</td><td style='font-weight: bold;'>{$login_id}</td></tr>
                            <tr><td style='padding: 8px 0; color: #9ca3af;'>Temp Password:</td><td style='font-weight: bold; color: #ef4444;'>{$temp_password}</td></tr>
                            <tr><td style='padding: 8px 0; color: #9ca3af;'>Admin Panel URL:</td><td><a href='https://yourdomain.com/admin-login' style='color: #00f0ff; text-decoration: none;'>Access Terminal</a></td></tr>
                        </table>

                        <h3 style='color: #ef4444; border-bottom: 1px solid #374151; padding-bottom: 5px; margin-top: 25px;'>SECURITY NOTICE</h3>
                        <p style='font-size: 13px; color: #d1d5db;'>For security protection, you must change your temporary password immediately after your first successful login. Never share your login credentials with anyone. All login activities are monitored by the NEXUS CORE Security System.</p>

                        <div style='margin-top: 30px; text-align: center; font-size: 11px; color: #6b7280;'>
                            <p>This email was automatically generated and securely delivered by the official NEXUS CORE Automation System.</p>
                            <p>Official Sender Email: subhambusiness566@gmail.com</p>
                        </div>
                    </div>
                </div>
            </body>
            </html>
            ";

            // --- Native PHP Mail Implementation for Live Hosting ---
            $subject = 'Welcome to NEXUS CORE - Your Management Account';
            
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            // Set the sender email exactly as requested
            $headers .= "From: NEXUS CORE Security <subhambusiness566@gmail.com>" . "\r\n";
            $headers .= "Reply-To: subhambusiness566@gmail.com" . "\r\n";

            // Attempt to send the email natively via the server
            $mailSent = mail($email, $subject, $htmlEmail, $headers);

            if ($mailSent) {
                echo json_encode([
                    'status' => 'success', 
                    'message' => "Account generated successfully. \n\nLogin ID: {$login_id}\nTemp Password: {$temp_password}\n\nThe system has successfully delivered the Welcome Email to " . $email
                ]);
            } else {
                // Fallback message if server mail() is disabled but account was created
                echo json_encode([
                    'status' => 'success', 
                    'message' => "Account generated successfully. \n\nLogin ID: {$login_id}\nTemp Password: {$temp_password}\n\nWarning: Account created, but your hosting provider blocked the native email dispatch."
                ]);
            }
        } catch (PDOException $e) {
            echo json_encode(['status' => 'error', 'message' => 'Database constraint violation. Login ID or Email may already exist.']);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => 'System Error: ' . $e->getMessage()]);
        }
        break;

    default:
        // Fallback for legacy specific endpoints mapped to the core router
        echo json_encode(['status' => 'error', 'message' => 'Unknown Core Directive.']);
        break;
}
?>
