<?php
header('Content-Type: application/json');
require_once '../config/database.php';
use App\Config\Database;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Access.']);
    exit;
}

$db = (new Database())->getConnection();

$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
$full_name = filter_input(INPUT_POST, 'full_name', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
$age = filter_input(INPUT_POST, 'age', FILTER_VALIDATE_INT);
$password = $_POST['password'] ?? '';

if (!$username || !$email || !$password) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
    exit;
}

$password_hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

try {
    $stmt = $db->prepare("INSERT INTO users (username, full_name, email, phone, age, password_hash, role, status) VALUES (?, ?, ?, ?, ?, ?, 'user', 'pending')");
    $stmt->execute([$username, $full_name, $email, $phone, $age, $password_hash]);
    echo json_encode(['status' => 'success', 'message' => 'Registration successful. Awaiting Admin approval.']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Username or Email already exists.']);
}
?>
