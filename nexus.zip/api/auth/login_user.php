<?php
header('Content-Type: application/json');
require_once '../config/database.php';
use App\Config\Database;

session_start();

$db = (new Database())->getConnection();

$identifier = filter_input(INPUT_POST, 'identifier', FILTER_SANITIZE_STRING);
$password = $_POST['password'] ?? '';

$stmt = $db->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
$stmt->execute([$identifier, $identifier]);
$user = $stmt->fetch();

if ($user && password_verify($password, $user['password_hash'])) {
    if ($user['status'] !== 'active') {
        echo json_encode(['status' => 'error', 'message' => 'Account pending approval.']);
        exit;
    }
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['username'] = $user['username'];
    echo json_encode(['status' => 'success', 'message' => 'Authentication successful. Redirecting...']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid credentials.']);
}
?>
