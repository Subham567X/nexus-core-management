<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit;
}

require_once 'api/config/database.php';
use App\Config\Database;

$dbClass = new Database();
$db = $dbClass->getConnection();

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$username = $_SESSION['username'];

// Fetch Stats
$totalUsers = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$activeProds = $db->query("SELECT COUNT(*) FROM productions WHERE status = 'active' OR status = 'planning'")->fetchColumn();
$pendingApprovals = $db->query("SELECT COUNT(*) FROM users WHERE status = 'pending'")->fetchColumn();
$totalUploads = $db->query("SELECT COUNT(*) FROM work_submissions")->fetchColumn();

// Fetch Pending Members for Admin
$pendingMembers = [];
if (in_array($user_role, ['super_admin', 'sub_admin'])) {
    $stmt = $db->query("SELECT id, username, role, status FROM users WHERE status = 'pending'");
    $pendingMembers = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch Productions
$productions = $db->query("SELECT id, name, progress FROM productions ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Fetch Recent Submissions
$submissions = $db->query("
    SELECT ws.id, ws.work_description, ws.status, u.username, p.name as prod_name 
    FROM work_submissions ws 
    JOIN users u ON ws.user_id = u.id 
    JOIN productions p ON ws.production_id = p.id 
    ORDER BY ws.submitted_at DESC LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Fetch Security Logs (Super Admin only)
$securityLogs = [];
if ($user_role === 'super_admin') {
    $securityLogs = $db->query("SELECT action_type, details, created_at FROM security_logs ORDER BY created_at DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nexus Core | Production Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@300;400;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>

    <!-- Sidebar Navigation -->
    <nav class="sidebar">
        <div class="sidebar-header">
            <i data-lucide="film" class="logo-icon"></i>
            <h2>NEXUS CORE</h2>
            <p>Studio Management System</p>
        </div>

        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item active"><i data-lucide="layout-dashboard"></i> Main Dashboard</a>
            
            <div class="menu-section">WORK AREA</div>
            <a href="#" class="menu-item" id="btn-work-update"><i data-lucide="upload-cloud"></i> Work Update Panel</a>
            <a href="#" class="menu-item" id="btn-assigned-tasks"><i data-lucide="check-square"></i> My Assigned Tasks</a>
            <a href="#" class="menu-item" id="btn-team-collab"><i data-lucide="message-square"></i> Team Collaboration</a>

            <div class="menu-section">DEPARTMENTS</div>
            <div class="menu-dropdown">
                <a href="#" class="menu-item dropdown-toggle"><i data-lucide="book-open"></i> Pre-Production <i data-lucide="chevron-down" class="chevron"></i></a>
                <div class="dropdown-content">
                    <a href="#">Story Development</a><a href="#">Storyboarding</a><a href="#">Concept Art</a><a href="#">Character Design</a>
                </div>
            </div>
            <div class="menu-dropdown">
                <a href="#" class="menu-item dropdown-toggle"><i data-lucide="box"></i> 3D Production <i data-lucide="chevron-down" class="chevron"></i></a>
                <div class="dropdown-content">
                    <a href="#">3D Modeling</a><a href="#">Texturing</a><a href="#">Rigging</a><a href="#">Animation</a><a href="#">Rendering Farm</a>
                </div>
            </div>
            <div class="menu-dropdown">
                <a href="#" class="menu-item dropdown-toggle"><i data-lucide="scissors"></i> Post-Production <i data-lucide="chevron-down" class="chevron"></i></a>
                <div class="dropdown-content">
                    <a href="#">Compositing</a><a href="#">Video Editing</a><a href="#">Color Grading</a>
                </div>
            </div>

            <div class="menu-section">ADMINISTRATION</div>
            <?php if ($user_role === 'super_admin'): ?>
            <a href="#" class="menu-item security-btn" id="btn-cybersecurity"><i data-lucide="shield-alert"></i> Cybersecurity Logs</a>
            <?php endif; ?>
            <?php if (in_array($user_role, ['super_admin', 'sub_admin'])): ?>
            <a href="#" class="menu-item admin-btn" id="btn-member-control"><i data-lucide="users-round"></i> Member Control</a>
            <?php endif; ?>
        </div>
        
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="avatar"><i data-lucide="user"></i></div>
                <div class="details">
                    <span class="name"><?= htmlspecialchars($username) ?></span>
                    <span class="role"><?= strtoupper(str_replace('_', ' ', $user_role)) ?></span>
                </div>
            </div>
            <button class="logout-btn" onclick="window.location.href='index.html'"><i data-lucide="log-out"></i></button>
        </div>
    </nav>

    <!-- Main Content Area -->
    <main class="main-content">
        <header class="top-header">
            <div class="search-bar">
                <i data-lucide="search"></i>
                <input type="text" placeholder="Search productions, tasks, or users...">
            </div>
            <div class="header-actions">
                <button class="icon-btn"><i data-lucide="bell"></i><span class="badge">0</span></button>
            </div>
        </header>

        <div class="dashboard-wrapper">
            
            <div class="welcome-banner">
                <div>
                    <h1>Welcome to Nexus Core Command</h1>
                    <p>System operating at optimal efficiency. Logged in as <?= htmlspecialchars($username) ?>.</p>
                </div>
                <?php if (in_array($user_role, ['super_admin', 'sub_admin'])): ?>
                <div style="display: flex; gap: 10px;">
                    <button class="action-btn primary" id="btn-new-prod"><i data-lucide="plus"></i> New Production</button>
                    <?php if ($user_role === 'super_admin'): ?>
                    <button class="action-btn" id="btn-new-team" style="border-color: var(--neon-warning); color: var(--neon-warning);"><i data-lucide="users"></i> New Team</button>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i data-lucide="users"></i></div>
                    <div class="stat-details"><h3>Registered Members</h3><p class="value"><?= $totalUsers ?></p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i data-lucide="clapperboard"></i></div>
                    <div class="stat-details"><h3>Active Productions</h3><p class="value"><?= $activeProds ?></p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i data-lucide="upload-cloud"></i></div>
                    <div class="stat-details"><h3>Total Uploads</h3><p class="value"><?= $totalUploads ?></p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i data-lucide="shield"></i></div>
                    <div class="stat-details"><h3>Pending Approvals</h3><p class="value" style="color: var(--neon-warning);"><?= $pendingApprovals ?></p></div>
                </div>
            </div>

            <div class="content-grid">
                <!-- Production Progress -->
                <div class="panel">
                    <div class="panel-header">
                        <h3>Production Progress</h3>
                        <button class="text-btn">View All</button>
                    </div>
                    <div class="progress-list">
                        <?php if (empty($productions)): ?>
                            <p style="color: var(--text-muted); font-size: 13px;">No active productions.</p>
                        <?php else: ?>
                            <?php foreach ($productions as $prod): ?>
                            <div class="progress-item">
                                <div class="prog-info"><span>Project: <?= htmlspecialchars($prod['name']) ?></span><span><?= $prod['progress'] ?>%</span></div>
                                <div class="prog-bar-container"><div class="prog-bar" style="width: <?= $prod['progress'] ?>%;"></div></div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Submissions -->
                <div class="panel">
                    <div class="panel-header">
                        <h3>Recent Work Submissions</h3>
                        <button class="text-btn">Review Uploads</button>
                    </div>
                    <div class="submission-list">
                        <?php if (empty($submissions)): ?>
                            <p style="color: var(--text-muted); font-size: 13px;">No recent submissions.</p>
                        <?php else: ?>
                            <?php foreach ($submissions as $sub): ?>
                            <div class="submission-item">
                                <div class="sub-icon"><i data-lucide="file-check"></i></div>
                                <div class="sub-details"><h4><?= htmlspecialchars($sub['work_description']) ?></h4><p><?= htmlspecialchars($sub['prod_name']) ?> • <?= htmlspecialchars($sub['username']) ?></p></div>
                                <div class="sub-status status-<?= strtolower($sub['status']) ?>"><?= ucfirst(str_replace('_', ' ', $sub['status'])) ?></div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- 1. Work Update Panel Modal -->
    <div id="modal-work-update" class="modal-overlay">
        <div class="modal-content" style="width: 500px;">
            <div class="modal-header"><h2>Submit Work Update</h2><button class="close-modal"><i data-lucide="x"></i></button></div>
            <form id="form-work-update">
                <input type="hidden" name="action" value="submit_work">
                <div class="input-group"><label>Task Title / Description</label><textarea name="description" rows="3" required></textarea></div>
                <div class="input-group"><label>Progress Percentage (0-100)</label><input type="number" name="progress" min="0" max="100" required></div>
                <div class="input-group"><label>Upload File</label><input type="file" name="work_file" required style="padding: 5px;"></div>
                <button type="submit" class="action-btn">Submit Work for Review</button>
            </form>
        </div>
    </div>

    <!-- 2. Member Approval Panel Modal -->
    <?php if (in_array($user_role, ['super_admin', 'sub_admin'])): ?>
    <div id="modal-member-control" class="modal-overlay">
        <div class="modal-content" style="width: 600px;">
            <div class="modal-header"><h2 style="color: var(--neon-warning);">Member Access Control</h2><button class="close-modal"><i data-lucide="x"></i></button></div>
            <div style="max-height: 400px; overflow-y: auto;">
                <table style="width: 100%; text-align: left; border-collapse: collapse; font-size: 13px;">
                    <tr style="border-bottom: 1px solid var(--panel-border);">
                        <th style="padding: 10px;">Username</th><th>Role</th><th>Status</th><th>Action</th>
                    </tr>
                    <?php if (empty($pendingMembers)): ?>
                    <tr><td colspan="4" style="padding: 10px; color: var(--text-muted);">No pending members.</td></tr>
                    <?php else: ?>
                        <?php foreach ($pendingMembers as $member): ?>
                        <tr id="member-row-<?= $member['id'] ?>" style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px;"><?= htmlspecialchars($member['username']) ?></td>
                            <td><?= ucfirst($member['role']) ?></td>
                            <td style="color: var(--neon-warning);">Pending</td>
                            <td><button class="action-btn" style="padding: 5px; font-size: 10px;" onclick="approveMember(<?= $member['id'] ?>)">Approve</button></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- 3. Create Production Modal -->
    <?php if (in_array($user_role, ['super_admin', 'sub_admin'])): ?>
    <div id="modal-create-production" class="modal-overlay">
        <div class="modal-content">
            <div class="modal-header"><h2>Initialize New Production</h2><button class="close-modal"><i data-lucide="x"></i></button></div>
            <form id="form-create-production">
                <div class="input-group"><label>Production Codename</label><input type="text" name="name" required></div>
                <div class="input-group"><label>Synopsis</label><textarea name="description" rows="3" required></textarea></div>
                <button type="submit" class="action-btn">Initialize Project</button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- 4. Create Team Modal -->
    <?php if ($user_role === 'super_admin'): ?>
    <div id="modal-create-team" class="modal-overlay">
        <div class="modal-content">
            <div class="modal-header"><h2>Establish New Team</h2><button class="close-modal"><i data-lucide="x"></i></button></div>
            <form id="form-create-team">
                <div class="input-group">
                    <label>Department</label>
                    <select name="department" required>
                        <option value="Pre-Production">Pre-Production</option>
                        <option value="3D Production">3D Production</option>
                        <option value="Post-Production">Post-Production</option>
                        <option value="Audio & Sound">Audio & Sound</option>
                    </select>
                </div>
                <div class="input-group"><label>Team Name</label><input type="text" name="team_name" required></div>
                <div class="input-group"><label>Allowed File Extensions (e.g. PNG,BLEND,MP4)</label><input type="text" name="allowed_extensions" required></div>
                <button type="submit" class="action-btn">Create Team</button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- 5. Cybersecurity Logs Modal -->
    <?php if ($user_role === 'super_admin'): ?>
    <div id="modal-cybersecurity" class="modal-overlay">
        <div class="modal-content" style="width: 700px;">
            <div class="modal-header"><h2 style="color: var(--neon-cyan);">Cybersecurity Event Logs</h2><button class="close-modal"><i data-lucide="x"></i></button></div>
            <div style="max-height: 400px; overflow-y: auto;">
                <table style="width: 100%; text-align: left; border-collapse: collapse; font-size: 13px;">
                    <tr style="border-bottom: 1px solid var(--panel-border); color: var(--neon-cyan);">
                        <th style="padding: 10px;">Timestamp</th><th>Action Type</th><th>Details</th>
                    </tr>
                    <?php if (empty($securityLogs)): ?>
                    <tr><td colspan="3" style="padding: 10px; color: var(--text-muted);">No security events recorded. System nominal.</td></tr>
                    <?php else: ?>
                        <?php foreach ($securityLogs as $log): ?>
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                            <td style="padding: 10px;"><?= $log['created_at'] ?></td>
                            <td style="color: var(--neon-warning);"><?= htmlspecialchars($log['action_type']) ?></td>
                            <td><?= htmlspecialchars($log['details']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script>
        lucide.createIcons();

        // Dropdowns
        document.querySelectorAll('.dropdown-toggle').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                btn.parentElement.classList.toggle('active');
            });
        });

        // Universal Modal Logic
        const modals = {
            'btn-new-prod': 'modal-create-production',
            'btn-new-team': 'modal-create-team',
            'btn-work-update': 'modal-work-update',
            'btn-member-control': 'modal-member-control',
            'btn-cybersecurity': 'modal-cybersecurity'
        };

        Object.keys(modals).forEach(btnId => {
            const btn = document.getElementById(btnId);
            if(btn) {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const modal = document.getElementById(modals[btnId]);
                    if(modal) modal.classList.add('active');
                });
            }
        });

        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.target.closest('.modal-overlay').classList.remove('active');
            });
        });

        async function sendToCore(formElement, successMsg) {
            const formData = new FormData(formElement);
            try {
                const res = await fetch('api/system_core.php', { method: 'POST', body: formData });
                const data = await res.json();
                alert(data.message);
                if(data.status === 'success') {
                    formElement.closest('.modal-overlay').classList.remove('active');
                    formElement.reset();
                    location.reload(); // Refresh to show new data
                }
            } catch(err) {
                alert('Connection Error to Core API.');
                console.error(err);
            }
        }

        const workForm = document.getElementById('form-work-update');
        if(workForm) {
            workForm.addEventListener('submit', (e) => {
                e.preventDefault(); sendToCore(e.target, '');
            });
        }
        
        async function approveMember(id) {
            const formData = new FormData();
            formData.append('action', 'approve_member');
            formData.append('target_user_id', id);
            
            try {
                const res = await fetch('api/system_core.php', { method: 'POST', body: formData });
                const data = await res.json();
                alert(data.message);
                if(data.status === 'success') {
                    document.getElementById('member-row-' + id).remove();
                }
            } catch(err) {
                alert('Error connecting to Core API.');
            }
        }

        const prodForm = document.getElementById('form-create-production');
        if(prodForm) {
            prodForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                try {
                    const res = await fetch('api/admin/create_production.php', { method: 'POST', body: formData });
                    const data = await res.json();
                    alert(data.message);
                    if(data.status === 'success') location.reload();
                } catch(err) {}
            });
        }

        const teamForm = document.getElementById('form-create-team');
        if(teamForm) {
            teamForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                try {
                    const res = await fetch('api/admin/create_team.php', { method: 'POST', body: formData });
                    const data = await res.json();
                    alert(data.message);
                    if(data.status === 'success') location.reload();
                } catch(err) {}
            });
        }

    </script>
</body>
</html>
