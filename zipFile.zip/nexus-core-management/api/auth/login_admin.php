<?php
header('Content-Type: application/json');
require_once '../config/database.php';
use App\Config\Database;

session_start();
$db = (new Database())->getConnection();

$identifier      = trim($_POST['identifier'] ?? '');
$password        = $_POST['password'] ?? '';
$security_phrase = trim($_POST['security_phrase'] ?? '');

if (!$identifier) {
    echo json_encode(['status' => 'error', 'message' => 'Admin ID is required.']);
    exit;
}

$stmt = $db->prepare("SELECT * FROM users WHERE (email = ? OR username = ?) AND role IN ('super_admin', 'sub_admin', 'team_moderator') AND status = 'active'");
$stmt->execute([$identifier, $identifier]);
$admin = $stmt->fetch();

if ($admin) {
    $pwOk     = $password && password_verify($password, $admin['password_hash']);
    $phraseOk = $security_phrase && $security_phrase === $admin['security_phrase'];

    if ($pwOk || $phraseOk) {
        $_SESSION['user_id']  = $admin['id'];
        $_SESSION['role']     = $admin['role'];
        $_SESSION['username'] = $admin['username'];

        // Log the login
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $db->prepare("INSERT INTO security_logs (user_id, action_type, ip_address, details) VALUES (?,?,?,?)")
           ->execute([$admin['id'], 'admin_login', $ip, 'Admin login: ' . $admin['username'] . ' [' . $admin['role'] . ']']);

        echo json_encode(['status' => 'success', 'message' => 'Override Accepted. Admin status verified.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Security Breach: Invalid Override Sequence.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Identity not found in Management Database.']);
}
?>
