<?php
header('Content-Type: application/json');
require_once '../config/database.php';
use App\Config\Database;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
    exit;
}

$dbClass = new Database();
$db = $dbClass->getConnection();

// Only allow setup if no super admin exists
$existing = $db->query("SELECT COUNT(*) FROM users WHERE role='super_admin'")->fetchColumn();
if ($existing > 0) {
    echo json_encode(['status' => 'error', 'message' => 'System already initialized. Owner account exists.']);
    exit;
}

$username        = trim($_POST['username']        ?? '');
$full_name       = trim($_POST['full_name']       ?? '');
$email           = trim($_POST['email']           ?? '');
$phone           = trim($_POST['phone']           ?? '');
$age             = intval($_POST['age']           ?? 0);
$password        = $_POST['password']             ?? '';
$security_phrase = trim($_POST['security_phrase'] ?? '');

if (!$username || !$full_name || !$email || !$password || !$security_phrase) {
    echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
    exit;
}
if (strlen($password) < 8) {
    echo json_encode(['status' => 'error', 'message' => 'Password must be at least 8 characters.']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid email address.']);
    exit;
}

$password_hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

try {
    $stmt = $db->prepare("INSERT INTO users (username, full_name, email, phone, age, password_hash, security_phrase, role, status)
                          VALUES (?, ?, ?, ?, ?, ?, ?, 'super_admin', 'active')");
    $stmt->execute([$username, $full_name, $email, $phone ?: '000-000-0000', $age ?: 0, $password_hash, $security_phrase]);

    $uid = $db->lastInsertId();
    $ip  = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $db->prepare("INSERT INTO security_logs (user_id, action_type, ip_address, details) VALUES (?,?,?,?)")
       ->execute([$uid, 'owner_setup', $ip, 'System initialized by owner: ' . $username]);

    echo json_encode(['status' => 'success', 'message' => 'Owner account created. System initialized. Redirecting to login...']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Setup failed: ' . $e->getMessage()]);
}
?>
