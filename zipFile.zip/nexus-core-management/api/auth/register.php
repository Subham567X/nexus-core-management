<?php
header('Content-Type: application/json');
require_once '../config/database.php';
use App\Config\Database;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Access.']);
    exit;
}

$db = (new Database())->getConnection();

$username  = trim($_POST['username']  ?? '');
$full_name = trim($_POST['full_name'] ?? '');
$email     = trim($_POST['email']     ?? '');
$phone     = trim($_POST['phone']     ?? '');
$age       = intval($_POST['age']     ?? 0);
$password  = $_POST['password']       ?? '';

if (!$username || !$email || !$password || !$full_name) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid email address.']);
    exit;
}
if (strlen($password) < 6) {
    echo json_encode(['status' => 'error', 'message' => 'Password must be at least 6 characters.']);
    exit;
}

$password_hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

try {
    $stmt = $db->prepare("INSERT INTO users (username, full_name, email, phone, age, password_hash, role, status)
                          VALUES (?, ?, ?, ?, ?, ?, 'user', 'pending')");
    $stmt->execute([$username, $full_name, $email, $phone, $age, $password_hash]);

    $uid = $db->lastInsertId();
    $ip  = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $db->prepare("INSERT INTO security_logs (user_id, action_type, ip_address, details) VALUES (?,?,?,?)")
       ->execute([$uid, 'user_register', $ip, 'New registration: ' . $username]);

    echo json_encode(['status' => 'success', 'message' => 'Registration successful. Awaiting Admin approval.']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Username or email already exists.']);
}
?>
