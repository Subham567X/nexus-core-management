<?php
header('Content-Type: application/json');
require_once '../config/database.php';
use App\Config\Database;

session_start();

$db = (new Database())->getConnection();

$identifier = trim($_POST['identifier'] ?? '');
$password   = $_POST['password'] ?? '';

if (!$identifier || !$password) {
    echo json_encode(['status' => 'error', 'message' => 'Username/email and password are required.']);
    exit;
}

$stmt = $db->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
$stmt->execute([$identifier, $identifier]);
$user = $stmt->fetch();

if ($user && password_verify($password, $user['password_hash'])) {
    if ($user['status'] === 'pending') {
        echo json_encode(['status' => 'error', 'message' => 'Account pending Admin approval. Please wait.']);
        exit;
    }
    if ($user['status'] === 'banned' || $user['status'] === 'suspended') {
        echo json_encode(['status' => 'error', 'message' => 'Account suspended. Contact system admin.']);
        exit;
    }
    $_SESSION['user_id']  = $user['id'];
    $_SESSION['role']     = $user['role'];
    $_SESSION['username'] = $user['username'];

    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $db->prepare("INSERT INTO security_logs (user_id, action_type, ip_address, details) VALUES (?,?,?,?)")
       ->execute([$user['id'], 'user_login', $ip, 'User login: ' . $user['username']]);

    echo json_encode(['status' => 'success', 'message' => 'Authentication successful. Redirecting...']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid credentials. Access denied.']);
}
?>
