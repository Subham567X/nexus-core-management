<?php
header('Content-Type: application/json');
require_once '../config/database.php';
use App\Config\Database;

session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized.']);
    exit;
}
if (!in_array($_SESSION['role'], ['super_admin', 'sub_admin'])) {
    echo json_encode(['status' => 'error', 'message' => 'Clearance Denied.']);
    exit;
}

$db   = (new Database())->getConnection();
$name = trim($_POST['name'] ?? '');
$desc = trim($_POST['description'] ?? '');

if (!$name) {
    echo json_encode(['status' => 'error', 'message' => 'Production name is required.']);
    exit;
}

try {
    $stmt = $db->prepare("INSERT INTO productions (name, description, status, progress, created_by) VALUES (?,?,'planning',0,?)");
    $stmt->execute([$name, $desc, $_SESSION['user_id']]);
    $id = $db->lastInsertId();

    $db->prepare("INSERT INTO security_logs (user_id, action_type, ip_address, details) VALUES (?,?,?,?)")
       ->execute([$_SESSION['user_id'], 'production_created', $_SERVER['REMOTE_ADDR'] ?? '', 'Production created: ' . $name]);

    echo json_encode(['status' => 'success', 'message' => '✓ Production "' . htmlspecialchars($name) . '" initialized. ID: ' . $id]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Failed: ' . $e->getMessage()]);
}
?>
