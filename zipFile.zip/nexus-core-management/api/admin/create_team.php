<?php
header('Content-Type: application/json');
require_once '../config/database.php';
use App\Config\Database;

session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized.']);
    exit;
}
if ($_SESSION['role'] !== 'super_admin') {
    echo json_encode(['status' => 'error', 'message' => 'Only Super Admin can create teams.']);
    exit;
}

$db = (new Database())->getConnection();

$department         = trim($_POST['department']         ?? '');
$team_name          = trim($_POST['team_name']          ?? '');
$allowed_extensions = trim($_POST['allowed_extensions'] ?? '');

if (!$department || !$team_name || !$allowed_extensions) {
    echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
    exit;
}

try {
    $stmt = $db->prepare("INSERT INTO teams (department, team_name, allowed_extensions) VALUES (?,?,?)");
    $stmt->execute([$department, $team_name, strtoupper($allowed_extensions)]);
    $id = $db->lastInsertId();

    $db->prepare("INSERT INTO security_logs (user_id, action_type, ip_address, details) VALUES (?,?,?,?)")
       ->execute([$_SESSION['user_id'], 'team_created', $_SERVER['REMOTE_ADDR'] ?? '', 'Team created: ' . $team_name . ' in ' . $department]);

    echo json_encode(['status' => 'success', 'message' => '✓ Team "' . htmlspecialchars($team_name) . '" established in ' . htmlspecialchars($department) . '. ID: ' . $id]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Failed: ' . $e->getMessage()]);
}
?>
