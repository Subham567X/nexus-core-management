<?php
namespace App\Config;

use PDO;
use PDOException;

class Database {
    private $db_path;
    public $conn;

    public function __construct() {
        $this->db_path = __DIR__ . '/../../nexus_core.sqlite';
    }

    public function getConnection() {
        $this->conn = null;
        try {
            $isNew = !file_exists($this->db_path);
            $this->conn = new PDO("sqlite:" . $this->db_path);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->conn->exec("PRAGMA journal_mode=WAL");
            $this->conn->exec("PRAGMA foreign_keys=ON");
            if ($isNew) {
                $this->initSchema();
            }
        } catch(PDOException $exception) {
            error_log("DB Connection Error: " . $exception->getMessage());
        }
        return $this->conn;
    }

    public function needsSetup() {
        if (!file_exists($this->db_path)) return true;
        try {
            $count = $this->conn->query("SELECT COUNT(*) FROM users WHERE role='super_admin' AND status='active'")->fetchColumn();
            return $count == 0;
        } catch (Exception $e) {
            return true;
        }
    }

    private function initSchema() {
        $sql = "
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username VARCHAR(50) NOT NULL UNIQUE,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            phone VARCHAR(20) NOT NULL DEFAULT '',
            age INTEGER NOT NULL DEFAULT 0,
            password_hash VARCHAR(255) NOT NULL,
            security_phrase VARCHAR(255) DEFAULT NULL,
            role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('super_admin','sub_admin','team_moderator','user')),
            status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','active','suspended','banned')),
            team_id INTEGER DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS teams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            department VARCHAR(100) NOT NULL,
            team_name VARCHAR(100) NOT NULL,
            allowed_extensions VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS productions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(200) NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'planning' CHECK(status IN ('planning','active','on_hold','completed','archived')),
            progress INTEGER DEFAULT 0,
            created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            production_id INTEGER NOT NULL,
            team_id INTEGER NOT NULL,
            assigned_to INTEGER DEFAULT NULL,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'pending' CHECK(status IN ('pending','in_progress','on_hold','completed')),
            deadline DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (production_id) REFERENCES productions(id) ON DELETE CASCADE,
            FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
            FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS work_submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            team_id INTEGER NOT NULL,
            production_id INTEGER NOT NULL,
            work_description TEXT NOT NULL,
            screenshot_path VARCHAR(255) DEFAULT NULL,
            file_path VARCHAR(255) DEFAULT NULL,
            progress_percentage INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending_review' CHECK(status IN ('pending_review','approved','rejected','needs_fix','featured')),
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
            FOREIGN KEY (production_id) REFERENCES productions(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS security_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER DEFAULT NULL,
            action_type VARCHAR(100) NOT NULL,
            ip_address VARCHAR(45),
            device_info TEXT,
            details TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER NOT NULL,
            team_id INTEGER DEFAULT NULL,
            receiver_id INTEGER DEFAULT NULL,
            message TEXT NOT NULL,
            sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
            FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
        );
        ";

        $this->conn->exec($sql);
        $this->seedTeams();
        // NO hardcoded super admin — owner registers via setup.php
    }

    private function seedTeams() {
        $teams = [
            ['Pre-Production', 'Story Development Team', 'PDF,DOCX,TXT'],
            ['Pre-Production', 'Storyboarding Team', 'PNG,JPG,PDF,PSD'],
            ['Pre-Production', 'Concept Art Team', 'BLEND,MA,MB,FBX,OBJ,GLB,PNG,JPG,PSD'],
            ['Pre-Production', 'Character Design Team', 'BLEND,MA,MB,FBX,OBJ,GLB,PNG,JPG,PSD'],
            ['Pre-Production', 'Research & Development Team', 'PDF,DOCX,TXT'],
            ['Pre-Production', 'Voice Planning Team', 'MP3,WAV,TXT'],
            ['3D Production', '3D Modeling Team', 'BLEND,MA,MB,FBX,OBJ,GLB,STL,ZTL'],
            ['3D Production', 'Texturing Team', 'PNG,JPG,PSD,SUBSTANCE FILES'],
            ['3D Production', 'Rigging Team', 'BLEND,MA,MB,FBX,OBJ,GLB'],
            ['3D Production', 'Animation Team', 'BLEND,MA,MB,FBX,GLB,MP4,MOV'],
            ['3D Production', 'Motion Capture Team', 'BVH,FBX,MP4'],
            ['3D Production', 'Environment Team', 'BLEND,MA,MB,FBX,OBJ,GLB,PNG,JPG'],
            ['3D Production', 'Lighting Team', 'BLEND,MA,MB,FBX,GLB,EXR,PNG'],
            ['3D Production', 'Camera & Cinematic Team', 'BLEND,MA,MB,FBX,GLB,MP4,MOV'],
            ['3D Production', 'Simulation Team', 'BLEND,MA,MB,FBX,GLB,VDB'],
            ['3D Production', 'VFX Team', 'BLEND,MA,MB,FBX,GLB,EXR,PNG,MP4'],
            ['3D Production', 'Rendering Team', 'BLEND,MA,MB,FBX,GLB,EXR,PNG,MP4'],
            ['Live Acting', 'Live Acting Team', 'MP4,MOV,JPG'],
            ['Post-Production', 'Compositing Team', 'EXR,NUKE FILES,AE FILES'],
            ['Post-Production', 'Video Editing Team', 'PR PROJECT,MP4,MOV'],
            ['Post-Production', 'Color Grading Team', 'LUT,MP4,MOV'],
            ['Post-Production', 'Sound Design Team', 'WAV,MP3,FLP'],
            ['Post-Production', 'Background Music Team', 'WAV,MP3,FL STUDIO PROJECT'],
            ['Post-Production', 'Voice Acting Team', 'WAV,MP3'],
            ['Post-Production', 'Singing Team', 'WAV,MP3,FLAC,OGG'],
            ['Post-Production', 'Music Production Team', 'FL STUDIO PROJECT,WAV,MP3,MIDI'],
            ['Post-Production', 'Lyrics Writing Team', 'TXT,DOCX,PDF'],
            ['Post-Production', 'Mixing & Mastering Team', 'WAV,FLP,MP3'],
            ['Post-Production', 'SFX Team', 'WAV,MP3,OGG,FLAC'],
            ['Post-Production', 'Foley Team', 'WAV,MP3,FLAC'],
            ['Post-Production', 'Ambient Sound Team', 'WAV,MP3,OGG'],
            ['Post-Production', 'Audio Cleanup Team', 'WAV,FLP,MP3'],
            ['Post-Production', 'Spatial Audio Team', 'WAV,MP3,MULTI-TRACK FILES'],
            ['Post-Production', 'Voice FX Team', 'WAV,MP3,FLP'],
            ['Post-Production', 'Final Mastering Team', 'MP4,MKV,MOV'],
            ['Cybersecurity', 'Cybersecurity Team', 'LOG,TXT,JSON,PDF'],
        ];
        $stmt = $this->conn->prepare("INSERT OR IGNORE INTO teams (department, team_name, allowed_extensions) VALUES (?,?,?)");
        foreach ($teams as $team) {
            $stmt->execute($team);
        }
    }
}
?>
