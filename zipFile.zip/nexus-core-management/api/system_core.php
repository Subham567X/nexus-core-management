<?php
header('Content-Type: application/json');
require_once 'config/database.php';
use App\Config\Database;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Access Protocol.']);
    exit;
}

session_start();
$action = $_POST['action'] ?? '';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized. Please authenticate.']);
    exit;
}

$dbClass   = new Database();
$db        = $dbClass->getConnection();
$user_id   = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

switch ($action) {

    // ── Submit Work ────────────────────────────────────────────────
    case 'submit_work':
        $production_id = intval($_POST['production_id'] ?? 0);
        $team_id       = intval($_POST['team_id']       ?? 0);
        $description   = trim($_POST['description']     ?? '');
        $progress      = max(0, min(100, intval($_POST['progress'] ?? 0)));

        if (!$description) {
            echo json_encode(['status' => 'error', 'message' => 'Work description is required.']);
            exit;
        }
        if (!$production_id) {
            echo json_encode(['status' => 'error', 'message' => 'Please select a production.']);
            exit;
        }
        if (!$team_id) {
            echo json_encode(['status' => 'error', 'message' => 'Please select your team.']);
            exit;
        }

        // Validate file upload
        $filePath = null;
        if (isset($_FILES['work_file']) && $_FILES['work_file']['error'] === UPLOAD_ERR_OK) {
            $fileName      = basename($_FILES['work_file']['name']);
            $fileExtension = strtoupper(pathinfo($fileName, PATHINFO_EXTENSION));

            // Get team's allowed extensions
            $teamRow = $db->prepare("SELECT allowed_extensions FROM teams WHERE id = ?");
            $teamRow->execute([$team_id]);
            $teamData = $teamRow->fetch();
            $allowed  = $teamData ? array_map('trim', explode(',', strtoupper($teamData['allowed_extensions']))) : [];

            if (!empty($allowed) && !in_array($fileExtension, $allowed)) {
                echo json_encode(['status' => 'error', 'message' => 'File type .' . $fileExtension . ' is not authorized for this team. Allowed: ' . implode(', ', $allowed)]);
                exit;
            }

            $uploadDir = 'uploads/work/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            $safeFile = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $fileName);
            if (move_uploaded_file($_FILES['work_file']['tmp_name'], $uploadDir . $safeFile)) {
                $filePath = $uploadDir . $safeFile;
            }
        }

        // Create a task record if none specified, or use production as context
        // Insert a generic task reference tied to the production
        try {
            // Check if there's a task for this production + team, or create one
            $task = $db->prepare("SELECT id FROM tasks WHERE production_id = ? AND team_id = ? LIMIT 1");
            $task->execute([$production_id, $team_id]);
            $taskRow = $task->fetch();

            if (!$taskRow) {
                // Auto-create a task for this production+team
                $teamName = $db->prepare("SELECT team_name FROM teams WHERE id = ?");
                $teamName->execute([$team_id]);
                $tn = $teamName->fetchColumn();
                $ins = $db->prepare("INSERT INTO tasks (production_id, team_id, assigned_to, title, status) VALUES (?,?,?,?,'in_progress')");
                $ins->execute([$production_id, $team_id, $user_id, $tn . ' Work']);
                $task_id = $db->lastInsertId();
            } else {
                $task_id = $taskRow['id'];
            }

            $stmt = $db->prepare("INSERT INTO work_submissions
                (task_id, user_id, team_id, production_id, work_description, file_path, progress_percentage, status)
                VALUES (?,?,?,?,?,?,?,'pending_review')");
            $stmt->execute([$task_id, $user_id, $team_id, $production_id, $description, $filePath, $progress]);

            // Log the submission
            $db->prepare("INSERT INTO security_logs (user_id, action_type, ip_address, details) VALUES (?,?,?,?)")
               ->execute([$user_id, 'work_submitted', $_SERVER['REMOTE_ADDR'] ?? '', 'Work submitted for production #' . $production_id]);

            echo json_encode(['status' => 'success', 'message' => 'Work submitted successfully. Progress: ' . $progress . '%. Status: Pending Review.']);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => 'Submission failed: ' . $e->getMessage()]);
        }
        break;

    // ── Approve Member ────────────────────────────────────────────
    case 'approve_member':
        if (!in_array($user_role, ['super_admin', 'sub_admin'])) {
            echo json_encode(['status' => 'error', 'message' => 'Clearance Denied.']);
            exit;
        }
        $target_id = intval($_POST['target_user_id'] ?? 0);
        if (!$target_id) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid user ID.']);
            exit;
        }
        $stmt = $db->prepare("UPDATE users SET status = 'active' WHERE id = ? AND status = 'pending'");
        $stmt->execute([$target_id]);

        $db->prepare("INSERT INTO security_logs (user_id, action_type, ip_address, details) VALUES (?,?,?,?)")
           ->execute([$user_id, 'member_approved', $_SERVER['REMOTE_ADDR'] ?? '', 'Member #' . $target_id . ' approved by ' . $_SESSION['username']]);

        echo json_encode(['status' => 'success', 'message' => 'Personnel access granted.']);
        break;

    // ── Reject Member ─────────────────────────────────────────────
    case 'reject_member':
        if (!in_array($user_role, ['super_admin', 'sub_admin'])) {
            echo json_encode(['status' => 'error', 'message' => 'Clearance Denied.']);
            exit;
        }
        $target_id = intval($_POST['target_user_id'] ?? 0);
        $stmt = $db->prepare("UPDATE users SET status = 'rejected' WHERE id = ? AND status = 'pending'");
        $stmt->execute([$target_id]);
        echo json_encode(['status' => 'success', 'message' => 'Access request rejected.']);
        break;

    // ── Review Work ───────────────────────────────────────────────
    case 'review_work':
        if (!in_array($user_role, ['super_admin', 'sub_admin', 'team_moderator'])) {
            echo json_encode(['status' => 'error', 'message' => 'Clearance Denied.']);
            exit;
        }
        $submission_id = intval($_POST['submission_id'] ?? 0);
        $new_status    = trim($_POST['status'] ?? '');
        $allowed_statuses = ['approved', 'rejected', 'needs_fix', 'featured', 'pending_review'];
        if (!in_array($new_status, $allowed_statuses)) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid status value.']);
            exit;
        }
        $stmt = $db->prepare("UPDATE work_submissions SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $submission_id]);
        echo json_encode(['status' => 'success', 'message' => 'Work submission updated to ' . strtoupper($new_status) . '.']);
        break;

    // ── Create Admin Account ──────────────────────────────────────
    case 'create_admin_account':
        if ($user_role !== 'super_admin') {
            echo json_encode(['status' => 'error', 'message' => 'CRITICAL SECURITY: Only Super Admin can provision Management Accounts.']);
            exit;
        }

        $full_name = trim($_POST['full_name'] ?? '');
        $email     = trim($_POST['email']     ?? '');
        $new_role  = trim($_POST['new_role']  ?? '');

        if (!$full_name || !$email || !$new_role) {
            echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
            exit;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid email format.']);
            exit;
        }
        if (!in_array($new_role, ['sub_admin', 'team_moderator'])) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid role selected.']);
            exit;
        }

        $login_id     = 'NEXUS_' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 6));
        $temp_password = 'NX-' . bin2hex(random_bytes(4)) . '!';
        $hashed       = password_hash($temp_password, PASSWORD_BCRYPT, ['cost' => 12]);
        $role_title   = ($new_role === 'sub_admin') ? 'Sub Admin' : 'Team Moderator';

        try {
            $stmt = $db->prepare("INSERT INTO users (username, full_name, email, password_hash, role, status)
                                  VALUES (?,?,?,?,?,'active')");
            $stmt->execute([$login_id, $full_name, $email, $hashed, $new_role]);

            $uid = $db->lastInsertId();
            $db->prepare("INSERT INTO security_logs (user_id, action_type, ip_address, details) VALUES (?,?,?,?)")
               ->execute([$user_id, 'admin_created', $_SERVER['REMOTE_ADDR'] ?? '', 'Created ' . $role_title . ': ' . $login_id]);

            // Build role-specific permissions block
            $sub_admin_perms = ($new_role === 'sub_admin') ? '
  <ul style="margin:10px 0 0 18px;padding:0;color:#d1d5db;font-size:13px;line-height:2;">
    <li>Team management</li>
    <li>Content moderation</li>
    <li>Project supervision</li>
    <li>User approvals</li>
    <li>System operations</li>
  </ul>' : '';
            $mod_perms = ($new_role === 'team_moderator') ? '
  <ul style="margin:10px 0 0 18px;padding:0;color:#d1d5db;font-size:13px;line-height:2;">
    <li>Task monitoring</li>
    <li>Team coordination</li>
    <li>Content review</li>
    <li>Workflow management</li>
  </ul>' : '';

            $subject = 'Welcome to NEXUS CORE \xe2\x80\x93 Your Management Account Has Been Created';
            $html = '<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>NEXUS CORE — Account Provisioned</title></head>
<body style="margin:0;padding:0;background-color:#05060a;font-family:Arial,Helvetica,sans-serif;color:#e2e8f0;">

<table width="100%" cellpadding="0" cellspacing="0" style="background-color:#05060a;padding:40px 20px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;border:1px solid #1f2937;border-radius:10px;overflow:hidden;box-shadow:0 0 40px rgba(0,240,255,0.08);">

  <!-- HEADER -->
  <tr>
    <td style="background:#080b10;padding:30px 30px 20px;text-align:center;border-bottom:2px solid #00f0ff;">
      <p style="margin:0 0 6px;font-size:11px;letter-spacing:4px;color:#64748b;text-transform:uppercase;">NEXUS CORE SECURITY SYSTEM</p>
      <h1 style="margin:0;font-size:28px;font-weight:900;letter-spacing:4px;text-transform:uppercase;color:#00f0ff;text-shadow:0 0 20px rgba(0,240,255,0.5);">NEXUS CORE</h1>
      <p style="margin:8px 0 0;font-size:12px;color:#9ca3af;letter-spacing:1px;">FILM PRODUCTION MANAGEMENT SYSTEM</p>
    </td>
  </tr>

  <!-- GREETING -->
  <tr>
    <td style="background:#0d1017;padding:30px 30px 10px;">
      <p style="margin:0 0 10px;font-size:15px;color:#e2e8f0;">Hello <strong style="color:#00f0ff;">' . htmlspecialchars($full_name) . '</strong>,</p>
      <p style="margin:0;font-size:14px;color:#9ca3af;line-height:1.7;">Welcome to <strong style="color:#e2e8f0;">NEXUS CORE</strong>. Your management account has been successfully created by the Super Admin team inside the NEXUS CORE Film Production Management System.</p>
    </td>
  </tr>

  <!-- DIVIDER -->
  <tr><td style="background:#0d1017;padding:20px 30px 0;">
    <div style="border-top:1px solid #1f2937;"></div>
    <p style="margin:16px 0 10px;font-size:11px;letter-spacing:3px;color:#00f0ff;text-transform:uppercase;">&#9472;&#9472; Account Details</p>
  </td></tr>

  <!-- ACCOUNT DETAILS TABLE -->
  <tr>
    <td style="background:#0d1017;padding:0 30px 20px;">
      <table width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #1f2937;border-radius:6px;overflow:hidden;">
        <tr style="background:#111827;">
          <td style="padding:12px 16px;font-size:12px;color:#64748b;width:44%;letter-spacing:1px;text-transform:uppercase;">Assigned Role</td>
          <td style="padding:12px 16px;font-size:13px;font-weight:bold;color:#f59e0b;">' . htmlspecialchars($role_title) . '</td>
        </tr>
        <tr style="background:#0f1520;">
          <td style="padding:12px 16px;font-size:12px;color:#64748b;letter-spacing:1px;text-transform:uppercase;">Login ID / Email</td>
          <td style="padding:12px 16px;font-size:13px;font-weight:bold;color:#e2e8f0;font-family:monospace;">' . htmlspecialchars($login_id) . '</td>
        </tr>
        <tr style="background:#111827;">
          <td style="padding:12px 16px;font-size:12px;color:#64748b;letter-spacing:1px;text-transform:uppercase;">Temporary Password</td>
          <td style="padding:12px 16px;font-size:13px;font-weight:bold;color:#ef4444;font-family:monospace;">' . htmlspecialchars($temp_password) . '</td>
        </tr>
        <tr style="background:#0f1520;">
          <td style="padding:12px 16px;font-size:12px;color:#64748b;letter-spacing:1px;text-transform:uppercase;">Official Admin Panel</td>
          <td style="padding:12px 16px;font-size:13px;"><a href="https://yourdomain.com/admin-login" style="color:#00f0ff;text-decoration:none;">Access Terminal &rarr;</a></td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- SECURITY NOTICE -->
  <tr><td style="background:#0d1017;padding:10px 30px 0;">
    <div style="border-top:1px solid #1f2937;"></div>
    <p style="margin:16px 0 10px;font-size:11px;letter-spacing:3px;color:#ef4444;text-transform:uppercase;">&#9472;&#9472; Security Notice</p>
  </td></tr>
  <tr>
    <td style="background:#0d1017;padding:0 30px 20px;">
      <div style="background:#160a0a;border:1px solid rgba(239,68,68,0.3);border-radius:6px;padding:16px 18px;">
        <p style="margin:0 0 8px;font-size:13px;color:#fca5a5;line-height:1.7;">&#9888; For security protection, you must <strong>change your temporary password immediately</strong> after your first successful login.</p>
        <p style="margin:0 0 8px;font-size:13px;color:#d1d5db;line-height:1.7;">&#128274; Never share your login credentials with anyone.</p>
        <p style="margin:0;font-size:13px;color:#d1d5db;line-height:1.7;">&#128269; All login activities and security events are monitored by the NEXUS CORE Security System.</p>
      </div>
    </td>
  </tr>

  <!-- ROLE & RESPONSIBILITIES -->
  <tr><td style="background:#0d1017;padding:0 30px 0;">
    <div style="border-top:1px solid #1f2937;"></div>
    <p style="margin:16px 0 10px;font-size:11px;letter-spacing:3px;color:#a855f7;text-transform:uppercase;">&#9472;&#9472; Role &amp; Responsibilities</p>
  </td></tr>
  <tr>
    <td style="background:#0d1017;padding:0 30px 24px;">
      <div style="background:#0f0a1a;border:1px solid rgba(168,85,247,0.25);border-radius:6px;padding:16px 18px;">
        <p style="margin:0 0 4px;font-size:13px;color:#c4b5fd;font-weight:bold;">Your assigned permissions depend on your management role.</p>
        ' . ($new_role === 'sub_admin' ? '
        <p style="margin:12px 0 4px;font-size:12px;color:#9ca3af;text-transform:uppercase;letter-spacing:1px;">Sub Admin permissions include:</p>' . $sub_admin_perms : '
        <p style="margin:12px 0 4px;font-size:12px;color:#9ca3af;text-transform:uppercase;letter-spacing:1px;">Team Moderator permissions include:</p>' . $mod_perms) . '
        <p style="margin:14px 0 0;font-size:12px;color:#64748b;font-style:italic;">Some advanced system settings remain restricted to Super Admin access only.</p>
      </div>
    </td>
  </tr>

  <!-- AUTOMATED INFO -->
  <tr><td style="background:#0d1017;padding:0 30px 0;">
    <div style="border-top:1px solid #1f2937;"></div>
    <p style="margin:16px 0 10px;font-size:11px;letter-spacing:3px;color:#64748b;text-transform:uppercase;">&#9472;&#9472; Automated System Information</p>
  </td></tr>
  <tr>
    <td style="background:#0d1017;padding:0 30px 20px;font-size:13px;color:#9ca3af;line-height:1.8;">
      <p style="margin:0;">This email was automatically generated and securely delivered by the official NEXUS CORE Automation System.</p>
      <p style="margin:8px 0 0;">Official Sender Email: <span style="color:#00f0ff;">subhambusiness566@gmail.com</span></p>
    </td>
  </tr>

  <!-- SUPPORT -->
  <tr><td style="background:#0d1017;padding:0 30px 0;">
    <div style="border-top:1px solid #1f2937;"></div>
    <p style="margin:16px 0 10px;font-size:11px;letter-spacing:3px;color:#64748b;text-transform:uppercase;">&#9472;&#9472; Support &amp; Security Help</p>
  </td></tr>
  <tr>
    <td style="background:#0d1017;padding:0 30px 24px;font-size:13px;color:#9ca3af;line-height:1.7;">
      <p style="margin:0;">If you experience login issues, suspicious activity, or security problems, contact the NEXUS CORE support system immediately.</p>
    </td>
  </tr>

  <!-- FOOTER -->
  <tr>
    <td style="background:#080b10;padding:20px 30px;text-align:center;border-top:1px solid #1f2937;">
      <p style="margin:0 0 6px;font-size:14px;color:#e2e8f0;font-weight:bold;">Welcome to the NEXUS CORE Management Team.</p>
      <p style="margin:0 0 12px;font-size:12px;color:#64748b;font-style:italic;">— NEXUS CORE System Automation</p>
      <p style="margin:0;font-size:11px;letter-spacing:2px;color:#374151;text-transform:uppercase;">Secure &bull; Futuristic &bull; Cinematic &bull; Intelligent</p>
    </td>
  </tr>

</table>
</td></tr>
</table>
</body></html>';

            $headers  = "MIME-Version: 1.0\r\n";
            $headers .= "Content-type: text/html; charset=UTF-8\r\n";
            $headers .= "From: NEXUS CORE System <subhambusiness566@gmail.com>\r\n";
            $headers .= "Reply-To: subhambusiness566@gmail.com\r\n";
            $mailSent = @mail($email, $subject, $html, $headers);

            $emailNote = $mailSent ? "Welcome email sent to {$email}." : "Account created. Note: Email delivery requires live SMTP hosting.";

            echo json_encode([
                'status'  => 'success',
                'message' => "✓ Account provisioned.\n\nLogin ID: {$login_id}\nTemp Password: {$temp_password}\nRole: {$role_title}\n\n{$emailNote}"
            ]);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => 'Failed: ' . $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['status' => 'error', 'message' => 'Unknown directive.']);
        break;
}
?>
