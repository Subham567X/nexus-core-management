document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();

    // ── View Toggle (Login <-> Register) ──────────────────────────
    document.querySelectorAll('.switch-link').forEach(link => {
        link.addEventListener('click', function () {
            const targetId = this.getAttribute('data-target');
            const zone = this.closest('[id$="-zone"]');
            const allViews = zone ? zone.querySelectorAll('.form-view') : document.querySelectorAll('.form-view');
            allViews.forEach(v => v.classList.remove('active'));
            const target = document.getElementById(targetId);
            if (target) target.classList.add('active');
        });
    });

    // ── Eye Password Toggle ───────────────────────────────────────
    document.querySelectorAll('.eye-toggle').forEach(eye => {
        eye.addEventListener('click', function () {
            const input = this.previousElementSibling;
            if (!input) return;
            if (input.type === 'password') {
                input.type = 'text';
                this.setAttribute('data-lucide', 'eye-off');
            } else {
                input.type = 'password';
                this.setAttribute('data-lucide', 'eye');
            }
            lucide.createIcons();
        });
    });

    // ── Helper: safe JSON parse (strips PHP deprecation noise) ────
    const safeJSON = (text) => {
        const i = text.indexOf('{');
        return JSON.parse(i !== -1 ? text.slice(i) : text);
    };

    // ── Generic alert helper ──────────────────────────────────────
    const showAlert = (el, message, type) => {
        if (!el) return;
        el.textContent = message;
        el.className = 'alert alert-' + type;
        el.style.display = 'block';
    };

    // ── User Login ────────────────────────────────────────────────
    const handleUserLogin = () => {
        const form = document.getElementById('form-user-login');
        if (!form) return;
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const alertEl = document.getElementById('user-login-alert');
            const btn = form.querySelector('button[type="submit"]');
            const origHTML = btn ? btn.innerHTML : '';
            if (btn) { btn.disabled = true; btn.innerHTML = '⟳ AUTHENTICATING...'; }
            try {
                const res  = await fetch('api/auth/login_user.php', { method: 'POST', body: new FormData(form) });
                const data = safeJSON(await res.text());
                showAlert(alertEl, data.message, data.status === 'success' ? 'success' : 'error');
                if (data.status === 'success') {
                    setTimeout(() => { window.location.href = 'dashboard.php'; }, 1200);
                } else {
                    if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
                }
            } catch {
                showAlert(alertEl, 'Connection error. Please try again.', 'error');
                if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
            }
        });
    };

    // ── User Registration ─────────────────────────────────────────
    const handleRegister = () => {
        const form = document.getElementById('form-user-register');
        if (!form) return;
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const alertEl = document.getElementById('user-register-alert');
            const pwd1 = document.getElementById('reg-pwd-1')?.value;
            const pwd2 = document.getElementById('reg-pwd-2')?.value;
            if (pwd1 !== pwd2) {
                showAlert(alertEl, '⚠ Passwords do not match. Re-enter credentials.', 'error');
                return;
            }
            const btn = form.querySelector('button[type="submit"]');
            const origHTML = btn ? btn.innerHTML : '';
            if (btn) { btn.disabled = true; btn.innerHTML = '⟳ TRANSMITTING...'; }
            try {
                const res  = await fetch('api/auth/register.php', { method: 'POST', body: new FormData(form) });
                const data = safeJSON(await res.text());
                showAlert(alertEl, data.status === 'success'
                    ? '✓ Registration sent! Awaiting Admin clearance. You will be notified once approved.'
                    : '⚠ ' + data.message,
                    data.status === 'success' ? 'success' : 'error');
                if (data.status === 'success') {
                    form.reset();
                    if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
                } else {
                    if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
                }
            } catch {
                showAlert(alertEl, '⚠ Connection error. Please try again.', 'error');
                if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
            }
        });
    };

    // ── Admin Login ───────────────────────────────────────────────
    const handleAdminLogin = () => {
        const form = document.getElementById('form-admin-login');
        if (!form) return;
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const alertEl = document.getElementById('admin-alert');
            const btn = form.querySelector('button[type="submit"]');
            const origHTML = btn ? btn.innerHTML : '';
            if (btn) { btn.disabled = true; btn.innerHTML = '⟳ VERIFYING CLEARANCE...'; }
            try {
                const res  = await fetch('api/auth/login_admin.php', { method: 'POST', body: new FormData(form) });
                const data = safeJSON(await res.text());
                showAlert(alertEl, data.message, data.status === 'success' ? 'success' : 'error');
                if (data.status === 'success') {
                    setTimeout(() => { window.location.href = 'dashboard.php'; }, 1200);
                } else {
                    if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
                }
            } catch {
                showAlert(alertEl, '⚠ Connection error. Please try again.', 'error');
                if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
            }
        });
    };

    handleUserLogin();
    handleRegister();
    handleAdminLogin();

    // ── Biometric / Face Scan toggle ──────────────────────────────
    const toggleFaceBtn      = document.getElementById('toggle-face-scan');
    const togglePwdBtn       = document.getElementById('toggle-password-mode');
    const faceScannerGroup   = document.getElementById('face-scanner-group');
    const adminPasswordGroup = document.getElementById('admin-password-group');
    const scanLaser          = document.getElementById('scan-laser');
    const webcamFeed         = document.getElementById('webcam-feed');
    const scannerStatus      = document.getElementById('scanner-status');
    const cameraIcon         = document.getElementById('camera-icon');
    const secPhraseGroup     = document.getElementById('security-phrase-group');
    const failBtn            = document.getElementById('face-scan-fail-btn');

    let activeStream = null;

    const stopStream = () => {
        if (activeStream) {
            activeStream.getTracks().forEach(t => t.stop());
            activeStream = null;
        }
        if (webcamFeed)  { webcamFeed.srcObject = null; webcamFeed.style.display = 'none'; }
        if (scanLaser)   scanLaser.style.display  = 'none';
        if (cameraIcon)  cameraIcon.style.display = 'block';
    };

    if (toggleFaceBtn) {
        toggleFaceBtn.addEventListener('click', () => {
            if (adminPasswordGroup) adminPasswordGroup.style.display = 'none';
            if (faceScannerGroup)   faceScannerGroup.style.display   = 'block';
            if (toggleFaceBtn)      toggleFaceBtn.style.display      = 'none';
            if (togglePwdBtn)       togglePwdBtn.style.display       = 'block';

            navigator.mediaDevices.getUserMedia({ video: true })
                .then(stream => {
                    activeStream = stream;
                    if (webcamFeed) {
                        webcamFeed.srcObject = stream;
                        webcamFeed.style.display = 'block';
                    }
                    if (cameraIcon)    cameraIcon.style.display    = 'none';
                    if (scanLaser)     scanLaser.style.display     = 'block';
                    if (scannerStatus) scannerStatus.textContent   = 'Scanning... Do not move.';

                    // Face scan is visual only — after 3s show security phrase for manual entry
                    setTimeout(() => {
                        stopStream();
                        if (scannerStatus)  scannerStatus.textContent  = 'Scan complete. Enter security phrase to confirm.';
                        if (secPhraseGroup) secPhraseGroup.style.display = 'block';
                    }, 3000);
                })
                .catch(() => {
                    if (scannerStatus)  scannerStatus.textContent  = 'Camera denied. Use Security Phrase below.';
                    if (secPhraseGroup) secPhraseGroup.style.display = 'block';
                });
        });
    }

    if (togglePwdBtn) {
        togglePwdBtn.addEventListener('click', () => {
            stopStream();
            if (adminPasswordGroup) adminPasswordGroup.style.display = 'block';
            if (faceScannerGroup)   faceScannerGroup.style.display   = 'none';
            if (secPhraseGroup)     secPhraseGroup.style.display     = 'none';
            if (toggleFaceBtn)      toggleFaceBtn.style.display      = 'block';
            if (togglePwdBtn)       togglePwdBtn.style.display       = 'none';
        });
    }

    if (failBtn) {
        failBtn.addEventListener('click', () => {
            stopStream();
            if (secPhraseGroup) secPhraseGroup.style.display = 'block';
        });
    }
});
