<?php
session_start();

require_once 'api/config/database.php';
use App\Config\Database;

$dbClass = new Database();
$db      = $dbClass->getConnection();

// If no super admin exists, redirect to owner setup
$hasOwner = $db->query("SELECT COUNT(*) FROM users WHERE role='super_admin' AND status='active'")->fetchColumn();
if (!$hasOwner) {
    header('Location: setup.php');
    exit;
}

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id   = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$username  = $_SESSION['username'];

$totalUsers       = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$activeProds      = $db->query("SELECT COUNT(*) FROM productions WHERE status IN ('active','planning')")->fetchColumn();
$pendingApprovals = $db->query("SELECT COUNT(*) FROM users WHERE status = 'pending'")->fetchColumn();
$totalUploads     = $db->query("SELECT COUNT(*) FROM work_submissions")->fetchColumn();

$pendingMembers = [];
if (in_array($user_role, ['super_admin', 'sub_admin'])) {
    $stmt = $db->query("SELECT id, username, full_name, role, status, created_at FROM users WHERE status = 'pending' ORDER BY created_at DESC");
    $pendingMembers = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$productions = $db->query("SELECT id, name, progress, status FROM productions ORDER BY id DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);

$submissions = [];
try {
    $submissions = $db->query("
        SELECT ws.id, ws.work_description, ws.status, ws.submitted_at, u.username, p.name as prod_name
        FROM work_submissions ws
        JOIN users u ON ws.user_id = u.id
        JOIN productions p ON ws.production_id = p.id
        ORDER BY ws.submitted_at DESC LIMIT 6
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}

$securityLogs = [];
if ($user_role === 'super_admin') {
    $securityLogs = $db->query("SELECT action_type, ip_address, details, created_at FROM security_logs ORDER BY created_at DESC LIMIT 15")->fetchAll(PDO::FETCH_ASSOC);
}

$allTeams = $db->query("SELECT id, department, team_name FROM teams ORDER BY department, team_name")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nexus Core | Production Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Exo+2:wght@300;400;600;700;900&family=Inter:wght@400;500;600&family=Share+Tech+Mono&display=swap" media="print" onload="this.media='all'">
    <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Exo+2:wght@300;400;600;700;900&family=Inter:wght@400;500;600&family=Share+Tech+Mono&display=swap"></noscript>
    <link rel="stylesheet" href="css/dashboard.css">
    <script src="js/vendor/lucide.min.js"></script>
</head>
<body>

<!-- ══════════════════════════════════════════════════
     SIDEBAR
══════════════════════════════════════════════════ -->
<nav class="sidebar">
    <div class="sidebar-header">
        <i data-lucide="film" class="logo-icon"></i>
        <h2>NEXUS CORE</h2>
        <p>Studio Management System</p>
        <div class="sys-status">
            <span class="sys-dot"></span>
            ALL SYSTEMS NOMINAL
        </div>
    </div>

    <div class="sidebar-menu">
        <a href="dashboard.php" class="menu-item active">
            <i data-lucide="layout-dashboard"></i> Main Dashboard
        </a>

        <div class="menu-section">WORK AREA</div>
        <a href="#" class="menu-item" id="btn-work-update">
            <i data-lucide="upload-cloud"></i> Work Update Panel
        </a>
        <a href="#" class="menu-item" id="btn-assigned-tasks">
            <i data-lucide="check-square"></i> My Assigned Tasks
        </a>
        <a href="#" class="menu-item" id="btn-team-collab">
            <i data-lucide="message-square"></i> Team Collaboration
        </a>

        <div class="menu-section">DEPARTMENTS</div>
        <div class="menu-dropdown">
            <a href="#" class="menu-item dropdown-toggle">
                <i data-lucide="book-open"></i> Pre-Production
                <i data-lucide="chevron-down" class="chevron"></i>
            </a>
            <div class="dropdown-content">
                <a href="#">Story Development</a>
                <a href="#">Storyboarding</a>
                <a href="#">Concept Art</a>
                <a href="#">Character Design</a>
                <a href="#">Research &amp; Dev</a>
                <a href="#">Voice Planning</a>
            </div>
        </div>
        <div class="menu-dropdown">
            <a href="#" class="menu-item dropdown-toggle">
                <i data-lucide="box"></i> 3D Production
                <i data-lucide="chevron-down" class="chevron"></i>
            </a>
            <div class="dropdown-content">
                <a href="#">3D Modeling</a>
                <a href="#">Texturing</a>
                <a href="#">Rigging</a>
                <a href="#">Animation</a>
                <a href="#">VFX</a>
                <a href="#">Rendering Farm</a>
            </div>
        </div>
        <div class="menu-dropdown">
            <a href="#" class="menu-item dropdown-toggle">
                <i data-lucide="scissors"></i> Post-Production
                <i data-lucide="chevron-down" class="chevron"></i>
            </a>
            <div class="dropdown-content">
                <a href="#">Compositing</a>
                <a href="#">Video Editing</a>
                <a href="#">Color Grading</a>
                <a href="#">Sound Design</a>
                <a href="#">Final Mastering</a>
            </div>
        </div>

        <div class="menu-section">ADMINISTRATION</div>
        <?php if ($user_role === 'super_admin'): ?>
        <a href="#" class="menu-item security-btn" id="btn-cybersecurity">
            <i data-lucide="shield-alert"></i> Cybersecurity Logs
        </a>
        <?php endif; ?>
        <?php if (in_array($user_role, ['super_admin', 'sub_admin'])): ?>
        <a href="#" class="menu-item admin-btn" id="btn-member-control">
            <i data-lucide="users-round"></i> Member Control
        </a>
        <?php endif; ?>
        <?php if ($user_role === 'super_admin'): ?>
        <a href="#" class="menu-item" id="btn-create-admin" style="color:var(--neon-purple);">
            <i data-lucide="user-cog"></i> Create Admin Account
        </a>
        <?php endif; ?>
    </div>

    <div class="sidebar-footer">
        <div class="avatar"><i data-lucide="user"></i></div>
        <div class="user-info">
            <div class="details">
                <span class="name"><?= htmlspecialchars($username) ?></span>
                <span class="role"><?= strtoupper(str_replace('_', ' ', $user_role)) ?></span>
            </div>
        </div>
        <button class="logout-btn" onclick="window.location.href='api/auth/logout.php'" title="Logout">
            <i data-lucide="log-out"></i>
        </button>
    </div>
</nav>

<!-- ══════════════════════════════════════════════════
     MAIN CONTENT
══════════════════════════════════════════════════ -->
<main class="main-content">
    <header class="top-header">
        <div class="search-bar">
            <i data-lucide="search"></i>
            <input type="text" placeholder="Search productions, tasks, members...">
        </div>
        <div class="header-actions">
            <button class="icon-btn" title="Notifications">
                <i data-lucide="bell"></i>
                <?php if ($pendingApprovals > 0): ?>
                <span class="badge"><?= $pendingApprovals ?></span>
                <?php endif; ?>
            </button>
            <button class="icon-btn" title="Settings">
                <i data-lucide="settings"></i>
            </button>
        </div>
    </header>

    <div class="dashboard-wrapper">

        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <div>
                <h1>Welcome to Nexus Core Command</h1>
                <p>System operating at optimal efficiency &mdash; Operator: <strong style="color:var(--neon-cyan);"><?= htmlspecialchars($username) ?></strong> &nbsp;|&nbsp; Clearance: <strong style="color:var(--neon-warning);"><?= strtoupper(str_replace('_',' ',$user_role)) ?></strong></p>
            </div>
            <?php if (in_array($user_role, ['super_admin', 'sub_admin'])): ?>
            <div style="display:flex;gap:10px;flex-shrink:0;">
                <button class="action-btn primary" id="btn-new-prod">
                    <i data-lucide="plus"></i> New Production
                </button>
                <?php if ($user_role === 'super_admin'): ?>
                <button class="action-btn" id="btn-new-team" style="border-color:var(--neon-warning);color:var(--neon-warning);">
                    <i data-lucide="users"></i> New Team
                </button>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon"><i data-lucide="users"></i></div>
                <div class="stat-details">
                    <h3>Registered Members</h3>
                    <p class="value"><?= $totalUsers ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(168,85,247,.08);border-color:rgba(168,85,247,.2);">
                    <i data-lucide="clapperboard" style="color:var(--neon-purple);"></i>
                </div>
                <div class="stat-details">
                    <h3>Active Productions</h3>
                    <p class="value" style="color:var(--neon-purple);"><?= $activeProds ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(0,255,136,.08);border-color:rgba(0,255,136,.2);">
                    <i data-lucide="upload-cloud" style="color:var(--neon-success);"></i>
                </div>
                <div class="stat-details">
                    <h3>Total Uploads</h3>
                    <p class="value" style="color:var(--neon-success);"><?= $totalUploads ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background:rgba(245,158,11,.08);border-color:rgba(245,158,11,.2);">
                    <i data-lucide="shield" style="color:var(--neon-warning);"></i>
                </div>
                <div class="stat-details">
                    <h3>Pending Approvals</h3>
                    <p class="value" style="color:var(--neon-warning);"><?= $pendingApprovals ?></p>
                </div>
            </div>
        </div>

        <!-- Content Grid -->
        <div class="content-grid">
            <!-- Production Progress -->
            <div class="panel">
                <div class="panel-header">
                    <h3>Production Pipeline</h3>
                    <?php if (in_array($user_role, ['super_admin','sub_admin'])): ?>
                    <button class="text-btn" id="btn-new-prod-2">+ New</button>
                    <?php endif; ?>
                </div>
                <div class="progress-list">
                    <?php if (empty($productions)): ?>
                        <p style="color:var(--text-muted);font-size:13px;font-family:'Share Tech Mono',monospace;padding:20px 0;text-align:center;">
                            No productions initialized yet.
                        </p>
                    <?php else: ?>
                        <?php foreach ($productions as $prod): ?>
                        <div class="progress-item">
                            <div class="prog-info">
                                <span><?= htmlspecialchars($prod['name']) ?></span>
                                <span style="color:var(--neon-cyan);"><?= $prod['progress'] ?>%</span>
                            </div>
                            <div class="prog-bar-container">
                                <div class="prog-bar" style="width:<?= $prod['progress'] ?>%;"></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Recent Submissions -->
            <div class="panel">
                <div class="panel-header">
                    <h3>Recent Submissions</h3>
                    <button class="text-btn" id="btn-work-update-2">Submit Work</button>
                </div>
                <div class="submission-list">
                    <?php if (empty($submissions)): ?>
                        <p style="color:var(--text-muted);font-size:13px;font-family:'Share Tech Mono',monospace;padding:20px 0;text-align:center;">
                            No work submissions recorded.
                        </p>
                    <?php else: ?>
                        <?php foreach ($submissions as $sub): ?>
                        <div class="submission-item">
                            <div class="sub-icon"><i data-lucide="file-check"></i></div>
                            <div class="sub-details">
                                <h4><?= htmlspecialchars(substr($sub['work_description'], 0, 40)) ?><?= strlen($sub['work_description']) > 40 ? '…' : '' ?></h4>
                                <p><?= htmlspecialchars($sub['prod_name']) ?> &bull; <?= htmlspecialchars($sub['username']) ?></p>
                            </div>
                            <div class="sub-status status-<?= strtolower($sub['status']) ?>">
                                <?= ucfirst(str_replace('_', ' ', $sub['status'])) ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</main>

<!-- ══════════════════════════════════════════════════
     MODALS
══════════════════════════════════════════════════ -->

<!-- 1. Work Update Panel -->
<div id="modal-work-update" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i data-lucide="upload-cloud" style="width:16px;height:16px;vertical-align:middle;margin-right:8px;"></i>Submit Work Update</h2>
            <button class="close-modal"><i data-lucide="x"></i></button>
        </div>
        <div class="modal-body">
            <div id="work-alert" class="alert"></div>
            <form id="form-work-update">
                <input type="hidden" name="action" value="submit_work">
                <div class="input-group">
                    <label>Production</label>
                    <select name="production_id" required>
                        <option value="" disabled selected>Select production...</option>
                        <?php
                        $allProds = $db->query("SELECT id, name FROM productions WHERE status IN ('active','planning') ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($allProds as $p): ?>
                        <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="input-group">
                    <label>Your Team</label>
                    <select name="team_id" required>
                        <option value="" disabled selected>Select team...</option>
                        <?php foreach ($allTeams as $t): ?>
                        <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['department'] . ' › ' . $t['team_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="input-group">
                    <label>Work Description</label>
                    <textarea name="description" rows="3" required placeholder="Describe what you've completed..."></textarea>
                </div>
                <div class="input-group">
                    <label>Progress Percentage (0–100)</label>
                    <input type="number" name="progress" min="0" max="100" required placeholder="75">
                </div>
                <div class="input-group">
                    <label>Upload Work File <span style="color:var(--text-muted);font-size:11px;">(optional)</span></label>
                    <input type="file" name="work_file" style="padding:8px;">
                </div>
                <button type="submit" class="action-btn">
                    <i data-lucide="send" style="width:14px;height:14px;"></i>
                    Submit for Review
                </button>
            </form>
        </div>
    </div>
</div>

<!-- 2. Assigned Tasks -->
<div id="modal-assigned-tasks" class="modal-overlay">
    <div class="modal-content" style="max-width:600px;">
        <div class="modal-header">
            <h2><i data-lucide="check-square" style="width:16px;height:16px;vertical-align:middle;margin-right:8px;"></i>My Assigned Tasks</h2>
            <button class="close-modal"><i data-lucide="x"></i></button>
        </div>
        <div class="modal-body">
            <p style="color:var(--text-muted);font-size:13px;font-family:'Share Tech Mono',monospace;padding:30px 0;text-align:center;">
                No tasks assigned yet. Check back with your Team Moderator.
            </p>
        </div>
    </div>
</div>

<!-- 3. Team Collaboration -->
<div id="modal-team-collab" class="modal-overlay">
    <div class="modal-content" style="max-width:600px;">
        <div class="modal-header">
            <h2><i data-lucide="message-square" style="width:16px;height:16px;vertical-align:middle;margin-right:8px;"></i>Team Collaboration</h2>
            <button class="close-modal"><i data-lucide="x"></i></button>
        </div>
        <div class="modal-body">
            <p style="color:var(--text-muted);font-size:13px;font-family:'Share Tech Mono',monospace;padding:20px 0;text-align:center;">
                Real-time team messaging coming soon. Stay connected.
            </p>
        </div>
    </div>
</div>

<!-- 4. Member Control -->
<?php if (in_array($user_role, ['super_admin', 'sub_admin'])): ?>
<div id="modal-member-control" class="modal-overlay">
    <div class="modal-content" style="max-width:680px;">
        <div class="modal-header">
            <h2 style="color:var(--neon-warning);text-shadow:0 0 10px rgba(245,158,11,.4);">
                <i data-lucide="users-round" style="width:16px;height:16px;vertical-align:middle;margin-right:8px;"></i>
                Member Access Control
            </h2>
            <button class="close-modal"><i data-lucide="x"></i></button>
        </div>
        <div class="modal-body">
            <table>
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Full Name</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($pendingMembers)): ?>
                    <tr><td colspan="5" style="text-align:center;padding:20px;color:var(--text-muted);font-family:'Share Tech Mono',monospace;">No pending clearance requests.</td></tr>
                <?php else: ?>
                    <?php foreach ($pendingMembers as $member): ?>
                    <tr id="member-row-<?= $member['id'] ?>">
                        <td style="color:var(--text-main);"><?= htmlspecialchars($member['username']) ?></td>
                        <td><?= htmlspecialchars($member['full_name']) ?></td>
                        <td style="color:var(--neon-cyan);font-family:'Share Tech Mono',monospace;"><?= ucfirst($member['role']) ?></td>
                        <td><span style="color:var(--neon-warning);font-family:'Share Tech Mono',monospace;font-size:10px;">PENDING</span></td>
                        <td style="display:flex;gap:6px;flex-wrap:wrap;">
                            <button class="action-btn" style="padding:5px 10px;font-size:10px;" onclick="approveMember(<?= $member['id'] ?>)">
                                <i data-lucide="check" style="width:12px;height:12px;"></i> Approve
                            </button>
                            <button class="action-btn" style="padding:5px 10px;font-size:10px;border-color:var(--neon-error);color:var(--neon-error);" onclick="rejectMember(<?= $member['id'] ?>)">
                                <i data-lucide="x" style="width:12px;height:12px;"></i> Reject
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- 5. Create Production -->
<?php if (in_array($user_role, ['super_admin', 'sub_admin'])): ?>
<div id="modal-create-production" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i data-lucide="clapperboard" style="width:16px;height:16px;vertical-align:middle;margin-right:8px;"></i>Initialize New Production</h2>
            <button class="close-modal"><i data-lucide="x"></i></button>
        </div>
        <div class="modal-body">
            <div id="prod-alert" class="alert"></div>
            <form id="form-create-production">
                <div class="input-group">
                    <label>Production Codename</label>
                    <input type="text" name="name" required placeholder="e.g. PROJECT HORIZON">
                </div>
                <div class="input-group">
                    <label>Synopsis / Description</label>
                    <textarea name="description" rows="3" placeholder="Brief description of the production..."></textarea>
                </div>
                <button type="submit" class="action-btn">
                    <i data-lucide="rocket" style="width:14px;height:14px;"></i>
                    Initialize Production
                </button>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- 6. Create Team -->
<?php if ($user_role === 'super_admin'): ?>
<div id="modal-create-team" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2 style="color:var(--neon-warning);text-shadow:0 0 10px rgba(245,158,11,.4);">
                <i data-lucide="users" style="width:16px;height:16px;vertical-align:middle;margin-right:8px;"></i>
                Establish New Team
            </h2>
            <button class="close-modal"><i data-lucide="x"></i></button>
        </div>
        <div class="modal-body">
            <div id="team-alert" class="alert"></div>
            <form id="form-create-team">
                <div class="input-group">
                    <label>Department</label>
                    <select name="department" required>
                        <option value="" disabled selected>Select department...</option>
                        <option value="Pre-Production">Pre-Production</option>
                        <option value="3D Production">3D Production</option>
                        <option value="Live Acting">Live Acting</option>
                        <option value="Post-Production">Post-Production</option>
                        <option value="Audio & Sound">Audio &amp; Sound</option>
                        <option value="Cybersecurity">Cybersecurity</option>
                    </select>
                </div>
                <div class="input-group">
                    <label>Team Name</label>
                    <input type="text" name="team_name" required placeholder="e.g. Advanced VFX Unit">
                </div>
                <div class="input-group">
                    <label>Allowed File Extensions (comma-separated)</label>
                    <input type="text" name="allowed_extensions" required placeholder="PNG,BLEND,MP4,FBX">
                </div>
                <button type="submit" class="action-btn" style="border-color:var(--neon-warning);color:var(--neon-warning);">
                    <i data-lucide="plus-circle" style="width:14px;height:14px;"></i>
                    Establish Team
                </button>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- 7. Cybersecurity Logs -->
<?php if ($user_role === 'super_admin'): ?>
<div id="modal-cybersecurity" class="modal-overlay">
    <div class="modal-content" style="max-width:740px;">
        <div class="modal-header">
            <h2><i data-lucide="shield-alert" style="width:16px;height:16px;vertical-align:middle;margin-right:8px;"></i>Cybersecurity Event Logs</h2>
            <button class="close-modal"><i data-lucide="x"></i></button>
        </div>
        <div class="modal-body">
            <table>
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Action Type</th>
                        <th>IP Address</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($securityLogs)): ?>
                    <tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-muted);font-family:'Share Tech Mono',monospace;">No security events recorded. System nominal.</td></tr>
                <?php else: ?>
                    <?php foreach ($securityLogs as $log): ?>
                    <tr>
                        <td style="font-family:'Share Tech Mono',monospace;font-size:11px;"><?= $log['created_at'] ?></td>
                        <td style="color:var(--neon-warning);font-family:'Share Tech Mono',monospace;"><?= htmlspecialchars($log['action_type']) ?></td>
                        <td style="font-family:'Share Tech Mono',monospace;font-size:11px;"><?= htmlspecialchars($log['ip_address'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($log['details'] ?? '—') ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- 8. Create Admin Account -->
<?php if ($user_role === 'super_admin'): ?>
<div id="modal-create-admin" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2 style="color:var(--neon-purple);text-shadow:0 0 10px rgba(168,85,247,.4);">
                <i data-lucide="user-cog" style="width:16px;height:16px;vertical-align:middle;margin-right:8px;"></i>
                Provision Management Account
            </h2>
            <button class="close-modal"><i data-lucide="x"></i></button>
        </div>
        <div class="modal-body">
            <div id="admin-create-alert" class="alert"></div>
            <form id="form-create-admin">
                <input type="hidden" name="action" value="create_admin_account">
                <div class="input-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" required placeholder="Full legal name">
                </div>
                <div class="input-group">
                    <label>Email Address</label>
                    <input type="email" name="email" required placeholder="admin@example.com">
                </div>
                <div class="input-group">
                    <label>Clearance Role</label>
                    <select name="new_role" required>
                        <option value="" disabled selected>Assign clearance...</option>
                        <option value="sub_admin">Sub Admin (Level 4)</option>
                        <option value="team_moderator">Team Moderator (Level 3)</option>
                    </select>
                </div>
                <button type="submit" class="action-btn" style="border-color:var(--neon-purple);color:var(--neon-purple);">
                    <i data-lucide="key" style="width:14px;height:14px;"></i>
                    Generate Credentials
                </button>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════
     SCRIPTS
══════════════════════════════════════════════════ -->
<script>
lucide.createIcons();

// ── Safe JSON parser (strips PHP warnings) ────────
function safeJSON(text) {
    const s = text.trim();
    const i = s.indexOf('{');
    if (i > 0) {
        try { return JSON.parse(s.slice(i)); } catch {}
    }
    try { return JSON.parse(s); } catch {}
    return { status: 'error', message: s || 'Unknown server error.' };
}

// ── Sidebar dropdown toggles ──────────────────────
document.querySelectorAll('.dropdown-toggle').forEach(btn => {
    btn.addEventListener('click', e => {
        e.preventDefault();
        btn.closest('.menu-dropdown').classList.toggle('active');
        lucide.createIcons();
    });
});

// ── Modal map ─────────────────────────────────────
const modalMap = {
    'btn-work-update':    'modal-work-update',
    'btn-work-update-2':  'modal-work-update',
    'btn-assigned-tasks': 'modal-assigned-tasks',
    'btn-team-collab':    'modal-team-collab',
    'btn-member-control': 'modal-member-control',
    'btn-new-prod':       'modal-create-production',
    'btn-new-prod-2':     'modal-create-production',
    'btn-new-team':       'modal-create-team',
    'btn-cybersecurity':  'modal-cybersecurity',
    'btn-create-admin':   'modal-create-admin',
};

Object.entries(modalMap).forEach(([btnId, modalId]) => {
    const btn = document.getElementById(btnId);
    if (btn) btn.addEventListener('click', e => {
        e.preventDefault();
        const modal = document.getElementById(modalId);
        if (modal) modal.classList.add('active');
    });
});

// Close buttons
document.querySelectorAll('.close-modal').forEach(btn => {
    btn.addEventListener('click', () => btn.closest('.modal-overlay').classList.remove('active'));
});

// Click outside to close
document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.classList.remove('active'); });
});

// ── Alert helper ──────────────────────────────────
function showModalAlert(id, msg, type) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = msg;
    el.className   = 'alert alert-' + type;
    el.style.display = 'block';
    if (type === 'success') setTimeout(() => { el.style.display = 'none'; }, 6000);
}

// ── Work Update submit ─────────────────────────────
const workForm = document.getElementById('form-work-update');
if (workForm) {
    workForm.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = workForm.querySelector('button[type="submit"]');
        const orig = btn ? btn.innerHTML : '';
        if (btn) { btn.disabled = true; btn.textContent = '⟳ TRANSMITTING...'; }
        try {
            const res  = await fetch('api/system_core.php', { method: 'POST', body: new FormData(e.target) });
            const data = safeJSON(await res.text());
            showModalAlert('work-alert', data.message, data.status === 'success' ? 'success' : 'error');
            if (data.status === 'success') { workForm.reset(); }
        } catch { showModalAlert('work-alert', 'Connection error.', 'error'); }
        finally { if (btn) { btn.disabled = false; btn.innerHTML = orig; } }
    });
}

// ── Approve Member ────────────────────────────────
async function approveMember(id) {
    const btn = event.target.closest('button');
    if (btn) { btn.disabled = true; btn.textContent = '⟳'; }
    const fd = new FormData();
    fd.append('action', 'approve_member');
    fd.append('target_user_id', id);
    try {
        const res  = await fetch('api/system_core.php', { method: 'POST', body: fd });
        const data = safeJSON(await res.text());
        if (data.status === 'success') {
            const row = document.getElementById('member-row-' + id);
            if (row) { row.style.transition = 'opacity .4s'; row.style.opacity = '0'; setTimeout(() => row.remove(), 400); }
        } else {
            alert('Error: ' + data.message);
            if (btn) { btn.disabled = false; btn.innerHTML = '<i data-lucide="check" style="width:12px;height:12px;"></i> Approve'; lucide.createIcons(); }
        }
    } catch {
        alert('Error connecting to Core API.');
        if (btn) { btn.disabled = false; btn.textContent = 'Approve'; }
    }
}

// ── Reject Member ─────────────────────────────────
async function rejectMember(id) {
    if (!confirm('Reject this member request?')) return;
    const fd = new FormData();
    fd.append('action', 'reject_member');
    fd.append('target_user_id', id);
    try {
        const res  = await fetch('api/system_core.php', { method: 'POST', body: fd });
        const data = safeJSON(await res.text());
        if (data.status === 'success') {
            const row = document.getElementById('member-row-' + id);
            if (row) { row.style.transition = 'opacity .4s'; row.style.opacity = '0'; setTimeout(() => row.remove(), 400); }
        }
    } catch { alert('Error connecting to Core API.'); }
}

// ── Create Production ─────────────────────────────
const prodForm = document.getElementById('form-create-production');
if (prodForm) {
    prodForm.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = prodForm.querySelector('button[type="submit"]');
        const orig = btn ? btn.innerHTML : '';
        if (btn) { btn.disabled = true; btn.textContent = '⟳ INITIALIZING...'; }
        try {
            const res  = await fetch('api/admin/create_production.php', { method: 'POST', body: new FormData(e.target) });
            const data = safeJSON(await res.text());
            showModalAlert('prod-alert', data.message, data.status === 'success' ? 'success' : 'error');
            if (data.status === 'success') { prodForm.reset(); setTimeout(() => location.reload(), 1600); }
        } catch { showModalAlert('prod-alert', 'Connection error.', 'error'); }
        finally { if (btn) { btn.disabled = false; btn.innerHTML = orig; } }
    });
}

// ── Create Team ───────────────────────────────────
const teamForm = document.getElementById('form-create-team');
if (teamForm) {
    teamForm.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = teamForm.querySelector('button[type="submit"]');
        const orig = btn ? btn.innerHTML : '';
        if (btn) { btn.disabled = true; btn.textContent = '⟳ ESTABLISHING...'; }
        try {
            const res  = await fetch('api/admin/create_team.php', { method: 'POST', body: new FormData(e.target) });
            const data = safeJSON(await res.text());
            showModalAlert('team-alert', data.message, data.status === 'success' ? 'success' : 'error');
            if (data.status === 'success') { teamForm.reset(); }
        } catch { showModalAlert('team-alert', 'Connection error.', 'error'); }
        finally { if (btn) { btn.disabled = false; btn.innerHTML = orig; } }
    });
}

// ── Create Admin Account ──────────────────────────
const adminCreateForm = document.getElementById('form-create-admin');
if (adminCreateForm) {
    adminCreateForm.addEventListener('submit', async e => {
        e.preventDefault();
        const btn = adminCreateForm.querySelector('button[type="submit"]');
        const orig = btn ? btn.innerHTML : '';
        if (btn) { btn.disabled = true; btn.textContent = '⟳ PROVISIONING...'; }
        try {
            const res  = await fetch('api/system_core.php', { method: 'POST', body: new FormData(e.target) });
            const data = safeJSON(await res.text());
            showModalAlert('admin-create-alert', data.message, data.status === 'success' ? 'success' : 'error');
            if (data.status === 'success') { adminCreateForm.reset(); }
        } catch { showModalAlert('admin-create-alert', 'Connection error.', 'error'); }
        finally { if (btn) { btn.disabled = false; btn.innerHTML = orig; } }
    });
}
</script>
</body>
</html>
